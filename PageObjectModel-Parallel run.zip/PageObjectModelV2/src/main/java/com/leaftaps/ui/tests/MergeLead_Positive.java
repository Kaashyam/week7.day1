package com.leaftaps.ui.tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.base.ProjectSpecificMethods;
import com.leaftaps.ui.pages.LoginPage;

public class MergeLead_Positive extends ProjectSpecificMethods {
	@BeforeTest
	public void setData() {
		excelFileName = "tc005";
	}
	
	@Test(dataProvider = "readData")
	public void tc005(String username, String password, String firstName, String firstName1) throws Exception {
		
		
			new LoginPage(driver)
			.typeUserName(username)
			.typePassword(password)
			.clickLogin()
			.clickCRMSFA()
			.clickLeads()
			.clickMergeLeads()
			.clickIMG1()
			.typeFirstName(firstName)
			.clickFindLeadsButton()
			.storeLeadID()
			.clickFirstLeadID1()
			.switchToPreviousWindow()
			.clickIMG2()
			.typeFirstName(firstName1)
			.clickFindLeadsButton()
			.clickFirstLeadID2()
			.switchBackToPreviousWindow()
			.clickMergeButton()
			.clickFindLeads()
			.enterLeadID()
			.clickFindLeadsButton()
			.verifyNoRecords();
		}
		
		
		
		

		
		
		/* Flow of Create Lead
		LoginPage page1 = new LoginPage();
		page1.typeUsername(username);
		page1.typePassword(password);
		page1.clickLoginButton();
		
		WelcomePage page2 = new WelcomePage();
		page2.clickCRMSFA();
		
		HomePage page3 = new HomePage();
		page3.clickLeads();
		
		MyLeadsPage page4 = new MyLeadsPage();
		page4.clickCreateLead();
		
		CreateLeadPage page5 = new CreateLeadPage();
		page5.typeCompanyName(cName);
		page5.typeFirstName(fName);
		page5.typeLastName(lName);
		page5.clickCreateLeadButton();
		
		ViewLeadPage page6 = new ViewLeadPage();
		page6.verifyLeadId();*/
	}



