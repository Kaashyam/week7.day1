package com.leaftaps.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class MergeLeadsPage extends ProjectSpecificMethods {
	public static List<String> allhandles;
	public static List<String> allhandles2;

	public MergeLeadsPage(RemoteWebDriver driver1) {
		this.driver = driver1;
	}
	public FindLeadsPage clickIMG1() {
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
		Set<String> allWindows = driver.getWindowHandles();
		allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));
		return new FindLeadsPage(driver);
	}

	public FindLeadsPage clickIMG2() {
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
		Set<String> allWindows = driver.getWindowHandles();
		allhandles2 = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles2.get(1));
		return new FindLeadsPage(driver);
	}

	public ViewLeadPage clickMergeButton() {
		driver.findElement(By.xpath("//a[text()='Merge']")).click();
		driver.switchTo().alert().accept();
		return new ViewLeadPage(driver);
	}
	public MergeLeadsPage switchToPreviousWindow() {
		driver.switchTo().window(allhandles.get(0));
		return this;
	}
		public MergeLeadsPage switchBackToPreviousWindow() {
			driver.switchTo().window(allhandles2.get(0));
			return this;
		}
	}


